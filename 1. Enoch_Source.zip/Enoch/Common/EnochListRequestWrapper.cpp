﻿#pragma once

#include "EnochListRequestWrapper.h"
#include <random>
#include <vector>
#include "Enoch/EnochGameInstance.h"

EnochListRequestWrapper::EnochListRequestWrapper(){}
EnochListRequestWrapper::~EnochListRequestWrapper(){}
