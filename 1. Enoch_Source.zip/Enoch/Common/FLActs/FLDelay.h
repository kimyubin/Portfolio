﻿#pragma once

#include"EnochFreeLancerAct.h"

class ENOCH_API FLDelay : public FreeLancerAct
{
public:
};