﻿#include "FLIdle.h"


void FLIdle::_Begin()
{
	data->SetTarget(-1);
}