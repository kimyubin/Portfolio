﻿#include "FLJump.h"
#include "../EnochFieldData.h"
#include "../EnochFieldCellData.h"
#include "../EnochFreeLancerData.h"
#include "../EnochActDelay.h"
#include "../EnochSimulator.h"


void FLJump::_Tick(float deltaTime)
{
	static double PI_Q = PI / 2;
	time += deltaTime;

	auto location2D = (postLocation - prevLocation) * (time / length);
	location2D = location2D + prevLocation;
	floatLocation = location2D;
}