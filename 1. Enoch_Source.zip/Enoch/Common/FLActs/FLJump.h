﻿#pragma once
#include "FLMove.h"

class ENOCH_API FLJump : public FLMove
{
public :
	void _Tick(float deltaTime);
};

