﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include <vector>
#include "Enoch/Common/EnochFreeLancerData.h"
#include "Enoch/Common/Commander.h"

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Components/Image.h"
#include "Enoch/DragImage.h"

#include "PlayMenuUIManager.generated.h"

using namespace std;

USTRUCT(BlueprintType)
struct FFreeLancerSlotData
{
	GENERATED_USTRUCT_BODY()
public:
	FFreeLancerSlotData():FreeLancerT(FreeLancerTemplateID::None),Material(nullptr) {};
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 FreeLancerT;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UMaterialInterface* Material;

};

UCLASS()
class ENOCH_API UPlayMenuUIManager : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	//드래그 drag이미지가 영역 밖으로 나가면 이미지 숨김.
	virtual void NativeOnDragEnter(const FGeometry& InGeometry, const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;
	virtual void NativeOnDragLeave(const FDragDropEvent& InDragDropEvent, UDragDropOperation* InOperation) override;

	/**
	* 상점 슬롯 이미지 저장하는 배열<br>
	* 엔진 BP 프로퍼티에서 이미지 교체 가능
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "ProfileImg")
	TArray<FFreeLancerSlotData> RecruitSlotDataArr;
	//드래그용 이미지. 별도의 블루프린트 위젯으로 만듦.
	UPROPERTY(meta = (BindWidget))
	UDragImage* DragImage;
	
	UPROPERTY(meta = (BindWidget))
    class UUniformGridPanel* RecruitUniformGridPanel;
	UPROPERTY(meta = (BindWidget))
    class UUniformGridPanel* InvenUniformGridPanel;
	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* SaveSlotVerticalBox;

	// UPROPERTY(meta = (BindWidget))
 //    UImage* FreeLancerInfoWidgetSlotImg;
	UPROPERTY(meta = (BindWidget))
	class UTextBlock* FailCommentText;	

	//UI를 뚫고 드롭하는 거 방지
	UPROPERTY(meta = (BindWidget))
	class UEnochFieldDropProtector* RecruitFieldDropProtector;
	UPROPERTY(meta = (BindWidget))
	class UEnochFieldDropProtector* InvenFieldDropProtector;
	
	FTimerHandle TimeHandler;
	/** 블루프린터에서 리롤함수 접근 기능 + 슬롯 이미지 업데이트 */
	UFUNCTION(BlueprintCallable, Category = "RecruitList")
	void RerollButtonRun();
	/** BP에서 판매 함수 접근 기능*/
	UFUNCTION(BlueprintCallable, Category = "SelectedFreeLancer")
    void SellButtonRun();
	
	/** Recruit 슬롯 초기화.<p>
	* 슬롯 번호, 용병 정보, 이미지 머티리얼 업데이트	*/
	void InitRecruitSlot();
	/** inven 슬롯 초기화.<p>
	 * 슬롯 번호, 용병 정보, 이미지 머티리얼 업데이트	*/
	void InitInvenSlot();
	void InitSaveSlot();
	/** 상점 단일 슬롯 이미지 변경. 리스트 데이터를 바탕으로 자동으로 변경
	 * @param ChangeSlot 슬롯 번호*/
	void SetRecruitSlotMat(const int& ChangeSlot);
	/** 인벤 단일 슬롯 이미지 변경. 리스트 데이터를 바탕으로 자동으로 변경
	 * @param ChangeSlot 슬롯 번호*/
	void SetInvenSlotMat(const int& ChangeSlot);
	// /** 현재 선택된 용병 이미지 머티리얼 자동 업데이트*/
	// UFUNCTION(BlueprintCallable, Category = "SelectedFreeLancer")
	// void SetSelectedFreeLancerMat();

	/** 드래그 이미지 숨김*/
	void DragImageHide();
	/** 드래그 이미지 보이기*/
	void DragImageVisible();
	/**구매, 스폰 등 실패시 실패된 내용을 UI에 노출 @param FailComment 실패 사유*/
	void NoticeFailComment(const FailReason& FailComment);
	void ClearFailComment();

	/** UI위에 있으면 뒤에 용병 선택, 스폰 안되는 기능*/
	bool IsHoverUI();

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* txtAllianceAlly;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* txtAllianceEnemy;

	void UpdateAllianceText(wstring ally, wstring enemy);
protected:	
};